#include "main.h"
extern uint16_t j;
struct key{
	uint8_t kindex;
	uint8_t klevel;
	uint8_t k;
	uint8_t ktime;
	uint8_t kl;
	
}k[3]={0};

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM4)
	{
		
		k[0].klevel=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_8);
		k[1].klevel=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_12);
		k[2].klevel=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_14);
		
		for(uint8_t i=0;i<3;i++)
		{
			switch(k[i].kindex)
			{
				case 0:
					if(k[i].klevel)
					{
						k[i].kindex=1;
						k[i].ktime=0;
					}
					break;
				case 1:
					if(k[i].klevel)
					{
						k[i].kindex=2;
						k[i].ktime++;
					}
					break;
				case 2:
					k[i].ktime++;
				if(!k[i].klevel&&k[i].ktime<20)
				{
					k[i].k=1;
					k[i].kindex=0;
				}
				if(!k[i].klevel&&k[i].ktime>50)
				{
					k[i].kl=1;
					k[i].kindex=0;
				}
					break;
			}			
		}
	}
}


