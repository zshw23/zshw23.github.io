#include "mymain.h"

uint8_t num1=1;
uint8_t jiemian;
uint8_t jiemianqiehuan=0;
double duty1,duty2;
float v1,v2;
enum cmd{
	zhuye=0,
	shezhi=1,
	tianqi=2,
	shizhong=3,
	naozhong
};
char uart1_tx[30]="1\n";//����
char uart1_rx[30];//����
char uart3_tx[30];//����
char uart3_rx[30];//����
void loop(void)
{
	
//	if(k[2].k==1)
//	{
//		duty1+=0.5;
//		
//		k[2].k=0;
//	}
//		if(k[1].k==1)
//	{
//		duty1-=0.5;
//		
//		k[1].k=0;
//	}
	
	

	
	if(k[0].kl==1)
	{
		jiemianqiehuan=!jiemianqiehuan;
		OLED_DrawBMP(20,2,127,8,cl,0);
		k[0].kl=0;
	}
	if(jiemianqiehuan==0)
	{
		if(k[0].k==1)
		{
			jiemian++;
			
			if(jiemian>=5)
				jiemian=0;
			k[0].k=0;
		}
		if(k[0].kl==1)
		{
			jiemianqiehuan=!jiemianqiehuan;
			OLED_Clear();
			k[0].kl=0;
		}
	}
	
	if(jiemian!=shezhi)
	{
			duty1=duty2=0;
	}
	
	
	switch (jiemian)
	{
		case zhuye://��ҳ
			OLED_Drawtub(0,0,naozhongt,0);
			OLED_Drawtub(0,3,shouye,1);
			OLED_Drawtub(0,6,shezhichanshu,0);
			OLED_ShowCHinese(52,0,25,0);
			OLED_ShowCHinese(66,0,26,0);
			if(jiemianqiehuan==1)
			{
				
			}
			break;
		case shezhi://����
			OLED_Drawtub(0,0,shouye,0);
			OLED_Drawtub(0,3,shezhichanshu,1);
			OLED_Drawtub(0,6,duoyun,0);
			OLED_ShowCHinese(52,0,27,0);
			OLED_ShowCHinese(66,0,28,0);
			if(jiemianqiehuan==1)
			{
				TIM2->CCR1=(1e6/50)*duty1/100.0f;
				TIM2->CCR2=(1e6/50)*duty2/100.0f;
				OLED_Showdecimal(48,1,duty1,3,3,16, 0);
				v1=(HAL_ADC_GetValue(&hadc1)*3.3f)/4096;
				v2=(HAL_ADC_GetValue(&hadc2)*3.3f)/4096;
				HAL_ADC_Start(&hadc1);
				HAL_ADC_Start(&hadc2);
				duty2=v1*0.606+0.5;
				duty1=v2*0.455+1;
				OLED_Showdecimal(48,3,v1,3,3,16, 0);
				OLED_Showdecimal(48,5,v2,3,3,16, 0);
			}			
			break;
		case tianqi://����
			OLED_Drawtub(0,0,shezhichanshu,0);
			OLED_Drawtub(0,3,duoyun,1);
			OLED_Drawtub(0,6,shizhongt,0);
			OLED_ShowCHinese(52,0,2,0);
			OLED_ShowCHinese(66,0,3,0);
			if(jiemianqiehuan==1)
			{
				OLED_ShowCHinese(20,3,4,0);
				OLED_ShowCHinese(36,3,5,0);
				OLED_ShowCHinese(52,3,23,0);
				
			  OLED_ShowCHinese(104,3,24,0);
				
			}	
			break;
		case shizhong://ʱ��
			OLED_Drawtub(0,0,duoyun,0);
			OLED_Drawtub(0,3,shizhongt,1);
			OLED_Drawtub(0,6,naozhongt,0);
			OLED_ShowCHinese(52,0,31,0);
			OLED_ShowCHinese(66,0,32,0);
			if(jiemianqiehuan==1)
			{
				
			}		
			break;
		case naozhong://����
			OLED_Drawtub(0,0,shizhongt,0);
			OLED_Drawtub(0,3,naozhongt,1);
			OLED_Drawtub(0,6,shouye,0);
			OLED_ShowCHinese(52,0,29,0);
			OLED_ShowCHinese(66,0,30,0);
			if(jiemianqiehuan==1)
			{
				
			}			
			break;
		default:
				
			break;
	}
	
}


void setup(void)
{
	
	HAL_ADC_Start(&hadc1);
	HAL_ADC_Start(&hadc2);
	HAL_ADCEx_Calibration_Start(&hadc1);
	HAL_ADCEx_Calibration_Start(&hadc2);
	HAL_TIM_Base_Start_IT(&htim4);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
//	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
//	HAL_UARTEx_ReceiveToIdle_IT(&huart1,(uint8_t*)uart1_rx,50);
//	HAL_UARTEx_ReceiveToIdle_IT(&huart3,(uint8_t*)uart3_rx,50);
//	
	HAL_UART_Receive_IT(&huart1, (uint8_t*)uart1_tx, sizeof(uart1_tx));
	HAL_UART_Receive_IT(&huart3, (uint8_t*)uart1_tx, sizeof(uart1_tx));
	jiemian=zhuye;
	OLED_Init();
	OLED_Clear();
	TIM2->ARR=1e6/50-1;//�������Ƶ��

	OLED_ShowCHinese(4,3,40,0);
	OLED_ShowCHinese(20,3,41,0);
	//OLED_ShowCHinese(36,3,35,0);
	OLED_ShowCHinese(52,3,36,0);
	OLED_ShowCHinese(68,3,37,0);
	OLED_ShowCHinese(84,3,38,0);
	OLED_ShowCHinese(100,3,39,0);
	
	HAL_Delay(3000);
	OLED_Clear();
	OLED_DrawBMP(18,0,19,8,shu,0);
}




//void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1) 
  {
   
  
  HAL_UART_Receive_IT(&huart1, (uint8_t*)uart1_tx, sizeof(uart1_tx));
		HAL_UART_Transmit(&huart3,(uint8_t*)uart1_tx,strlen(uart1_tx),50);
	}
	if (huart->Instance == USART3) 
  {
   
  HAL_UART_Receive_IT(&huart3, (uint8_t*)uart1_tx, sizeof(uart1_tx));
  
	
	HAL_UART_Transmit(&huart3,(uint8_t*)uart1_tx,strlen(uart1_tx),50);
	}
	
	
}

//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{

//}