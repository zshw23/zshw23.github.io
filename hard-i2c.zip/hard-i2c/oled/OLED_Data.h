#ifndef __OLED_DATA_H
#define __OLED_DATA_H


extern const unsigned char F6x8[][6];
extern const unsigned char F8X16[];
extern const unsigned char Hzk[][32];
extern const unsigned char Hzk32[][32];
extern unsigned char BMP1[];
extern unsigned char shezhichanshu[];
extern unsigned char bingbao[];
extern unsigned char shouye[];
extern unsigned char xunjianguanli[];
extern unsigned char duoyun[];
extern unsigned char shizhongt[];
extern unsigned char naozhongt[];
extern unsigned char shu[];
extern unsigned char cl[];
//extern unsigned char BMP2[].........
#endif /* OLED_OLEDFONT_H_ */

