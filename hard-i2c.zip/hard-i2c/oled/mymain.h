#ifndef _MYMAIN_H
#define _MYMAIN_H
#include "main.h"
#include "OLED.h"
#include "key.h"
#include "tim.h"
#include "adc.h"
#include "usart.h"
#include "string.h"
void setup(void);
void loop(void);
#endif
